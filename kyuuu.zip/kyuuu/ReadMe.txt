                                       Info Creator :
  Kyuu Official YT (watashi🕊️)
                                  
                                            tqto :
         iPutu Ofc (base)
             HenzZ (My Friend)
                 Rifal Mods (My Friend)
                     Adiwajshing (Baileys)
                        whiskeysockets (Baileys)
                                              NOTE :
                           Kalau Lu Hapus Ini
                              Gw Sumpahin Hidup Lu Akan Susah                         
                                 want more free bot scripts?
                                    subscribe to my youtube channel
                                        https://youtube.com/@YTKyuuTense       
                                        
                                         
                                          
                                           
                                            
                                             
                                      #BANTAI_MARK_ZUBERG 